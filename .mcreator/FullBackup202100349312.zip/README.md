<p><span style="font-family: terminal, monaco, monospace; font-size: 36px; color: #000000;"><strong>MONEYS!&nbsp;<span style="font-size: 8px;">definitely high quality.</span></strong></span></p>
<p><span style="font-family: terminal, monaco, monospace; font-size: 18px; color: #000000;"><strong>NOW WITH ITS BROTHER!</strong>&nbsp;<span style="font-size: 10px;">moneys 2....</span></span></p>
<p><span style="font-size: 1.2rem;">&nbsp;</span></p>
<p>&nbsp;</p>
<p><span style="font-size: 14px; font-family: 'andale mono', monospace;">Moneys Is A Mod That Adds .... Moneys?</span></p>
<p><span style="font-size: 14px; font-family: 'andale mono', monospace;">(Work In Progress)</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size: 14px; font-family: 'andale mono', monospace;">These Moneys are useless in singleplayer btw. (for now)</span></p>
<p>&nbsp;</p>
<p><span style="font-family: 'andale mono', monospace;">You Can Find Ripped Money in New Structure (Raided House)</span></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-family: 'andale mono', monospace; font-size: 18px;">You Can Make 10 Types of Money (No Shape Is Required)</span></p>
<blockquote>
<ul>
<li><span style="font-size: 14px; font-family: 'courier new', courier, monospace;">1 Minecoin - Requires 1x Paper, 1x Yellow Dye, 1x Black Dye</span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">5 Minecoin - 5x 1 Mineooin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">10 Minecoin - 2x 5 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">20 Minecoin - 2x 10 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">50 Minecoin - 2x 20 Minecoin, 1x 10 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">100 Minecoin - 2x 50 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">200 Minecoin - 2x 100 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">500 Minecoin - 2x 200 Minecoin, 1x 100 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">1000 Minecoin - 2x 500 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">2000 Minecoin - 2x 1000 Minecoin</span></span></li>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">5000 Minecoin - 2x 2000 Minecoin, 1x 1000 Minecoin</span></span></li>
</ul>
</blockquote>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span style="font-size: 24px;"><strong><span style="font-family: 'courier new', courier, monospace;">Other Items / Blocks</span></strong></span></p>
<blockquote>
<ul>
<li><span style="font-family: 'courier new', courier, monospace;"><span style="font-size: 14px;">Reburner - 4x Cobblestone, 3x Smooth Stone, 1x Dispenser, 1x Lava Bucket</span></span></li>
</ul>
</blockquote>
